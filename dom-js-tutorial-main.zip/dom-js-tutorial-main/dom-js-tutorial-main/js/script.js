//id chaqrish

let chooseBtn = document.getElementById(element='choose'),
receiveBtn = document.getElementById(element='receive'),

//class chaqirish

contactform = document.getElementsByClassName(element='contactform_name')[0],

contactForm = document.getElementsByClassName(element='contactform_phone')[0],

//elementni chaqirish

text = document.getElementsByTagName('h2')[0],

main = document.getElementsByTagName('h1')[0],

modal = document.querySelector(selectors='.modal'),

btn = document.querySelector(selectors='.main_tel_title'),

closeBtn = document.querySelector(selectors='.close'),

message = document.getElementsByName(elementName='message')[0],
Телефон = document.getElementsByName(elementName='Телефон')[0];

console.log(closeBtn);


// js yordamida so'zni almashtirish
text.addEventListener('mouseenter', function(){
    text.textContent = 'hammasi tugadi';
});

text.addEventListener('mouseleave', function (){
    text.textContent = 'Все включено'
})

// modal chiqarish
receiveBtn.addEventListener(type='click', listener=function(){
    modal.style.display='block';
});

closeBtn.addEventListener(type='click', listener=function(){
    modal.style.display = 'none';
});



//modalga yozilgan ma'lumotlarni textarega chiqarish
contactform.addEventListener('input', function(){
    message.value = `Mening ismi ${contactform.value} va men haqimda.......`;
})




// uy ishi
// 2-javob
contactForm.addEventListener('input', function(){
    message.value = `Mening tel ${contactForm.value} raqamim...`;
})